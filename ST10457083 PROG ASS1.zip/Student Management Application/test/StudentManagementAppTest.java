/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Dell
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import student.management.application.StudentManagementApp;

/**
 *
 * @author Dell
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import student.management.application.StudentManagementApp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import student.management.application.StudentManagementApp;


class StudentManagementAppTest {

    @Test
    void testSaveStudent() {
       
        StudentManagementApp.getStudents().clear();


        StudentManagementApp.captureNewStudent("S001", "John Doe", 18, "john.doe@example.com", "Software Engineering");

   
        assertEquals(1, StudentManagementApp.getStudents().size());
    }

    @Test
    void testSearchStudent() {
     
        StudentManagementApp.getStudents().clear();

      
        StudentManagementApp.captureNewStudent("ST10457688", "Anza Smith", 20, "ST10457688@rcconnect.edu.za.com", "Data Science");

       
        Student student = StudentManagementApp.searchStudent("ST10457688");

     
        assertNotNull(student);
        assertEquals("Anza Smith", student.getName());
    }

    @Test
    void testDeleteStudent() {
    
        StudentManagementApp.getStudents().clear();

     
        StudentManagementApp.captureNewStudent("ST10457083", "Hlompho Petja", 18, "ST10457083@rcconnect.edu.za", "Cybersecurity");

        boolean result = StudentManagementApp.deleteStudent("ST10457083");

    
        assertTrue(result);
        assertEquals(0, StudentManagementApp.getStudents().size());
    }
}
