/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package student.management.application;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Dell
 */
import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagementApp {
    private static ArrayList<Student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("1. Capture New Student");
            System.out.println("2. Search for Student");
            System.out.println("3. Delete Student");
            System.out.println("4. View Student Report");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    captureNewStudent();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    viewStudentReport();
                    break;
                case 5:
                    System.out.println("Exiting application.");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 5);
    }

    public static void captureNewStudent(String studentID, String name, int age, String email, String course) {
        students.add(new Student(studentID, name, age, email, course));
        System.out.println("Student details saved successfully.");
    }

    private static void captureNewStudent() {
        System.out.print("Enter Student ID: ");
        String studentID = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        int age = 0;
        while (true) {
            System.out.print("Enter Age (16 or older): ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) break;
                else System.out.println("Invalid age. Age must be 16 or older.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Course: ");
        String course = scanner.nextLine();

        captureNewStudent(studentID, name, age, email, course);
    }

   
    public static Student searchStudent(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                return student;
            }
        }
        return null;
    }

    
    

    
    private static void searchStudent() {
        System.out.print("Enter Student ID to search: ");
        String studentID = scanner.nextLine();
        Student student = searchStudent(studentID);
        if (student != null) {
            student.displayDetails();
        } else {
            System.out.println("Student not found.");
        }
    }


    public static boolean deleteStudent(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                students.remove(student);
                System.out.println("Student deleted successfully.");
                return true;
            }
        }
        System.out.println("Student not found.");
        return false;
    }


    private static void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        String studentID = scanner.nextLine();
        deleteStudent(studentID);
    }


    public static void viewStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            System.out.println("Student Report:");
            for (Student student : students) {
                student.displayDetails();
            }
        }
    }

  
    public static ArrayList<Student> getStudents() {
        return students;
    }
}